function route (handle,pathname){
    console.log("routing a request :" + pathname);
    if (typeof handle[pathname] === 'function'){
        handle[pathname]();

    }else {
        console.log("no handler file" + pathname);
    }
}

exports.route = route;
