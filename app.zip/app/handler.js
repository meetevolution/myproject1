function home(){
    console.log("executing 'home' handler");
}
function meet(){

    console.log("excuting 'meet' handler");
}

exports.home = home
exports.meet = meet;