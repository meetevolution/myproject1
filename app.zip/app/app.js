// var http = require('http')

// http.createServer(function (req,res){
//     res.writeHead(200,({'Content-Type':'text/plain'}))
//     res.write("hello world ")
//     res.end()
// }).listen(8181)

// let fs = require('fs');

// let readablestream = fs.createReadStream("input.txt")
// let writeablestream = fs.createWriteStream( "output.txt");

// readablestream.pipe(writeablestream);

let server = require("./server")
let router = require( './router' )
let handler = require('./handler')

let handle = {};
handle['/'] = handler.home;
handle["/home"] = handler.home;
handle['/meet'] =  handler.meet;

server.startserver(router.route,handle);
