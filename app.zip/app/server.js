
let http = require("http");
let url = require('url')
let route = require( './router' )
function startserver(route,handle){
http.createServer((req,res)=>{
    let pathname = url.parse(req.url).pathname;
    console.log("request received for" + pathname);
    console.log("request send");
    route(handle,pathname);
    res.writeHead(200,{'Content-Type':'text/plain'});
    res.write("hello from the server module")
    res.end()

}).listen(8888)
console.log("server is running port 8888");
}
exports.startserver = startserver;