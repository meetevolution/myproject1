const express = require('express');
const bodyParser = require('body-parser');
const connectDB = require('./db');
const upload = require('./multer_config');
const File = require('./model/file');
const app = express();
connectDB();
app.use(bodyParser.json());
app.post('/upload', upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ message: 'No file uploaded' });
        }
        const newFile = new File({
            filename: req.file.originalname,
            path: req.file.path,
            size: req.file.size,
            contentType: req.file.mimetype
        });         
        const savedFile = await newFile.save();
        res.status(201).json({ message: 'File uploaded successfully', file: savedFile });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

const PORT = process.env.PORT || 3000; // Use environment variable for port or default to 3000

app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});