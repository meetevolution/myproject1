const mongoose = require('mongoose');

const FileSchema = new mongoose.Schema({
    name :{
            type: String,  
          
    },
    filename: {
        type: String,
   
    },
    path: {
        type: String,
      
    },
    size: {
        type: Number,
       
    },
   
});

module.exports = mongoose.model('File', FileSchema);    